"""Core engine package for Patchwork Isles."""

